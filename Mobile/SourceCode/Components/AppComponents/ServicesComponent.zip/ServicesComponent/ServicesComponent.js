import React from 'react';
import { View, Text, TextInput, StyleSheet, Image, ImageBackground, TouchableOpacity, ScrollView,Platform } from 'react-native';
import { widthPercentageToDP as wp, heightPercentageToDP as hp } from 'react-native-responsive-screen';
import colors from '../../../Assets/Colors/colors';
import images from '../../../Assets/Images/images';



export default class ServicesComponent extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            viewShow: true,
        }

    }


    render() {

        return (

            <View style={styles.mainContainer}>

                <TouchableOpacity style={[styles.itemList,]} onPress={this.props.onPressItem}>
                    <View style={styles.imageView}>
                        <View style={styles.viewTitle}>
                            <Image style={[styles.icon]} source={this.props.image} />
                            <Text style={styles.title}>{this.props.title}</Text>
                        </View>
                        <Text style={{fontStyle:'italic'}}>{this.props.timing}</Text>

                    </View>
                    <View style={[styles.textView]}>
                        <Text numberOfLines={1} style={[styles.addressText,]}>{this.props.address}</Text>
                        <Text numberOfLines={1} style={styles.text}>{this.props.distance}</Text>
                    </View>
                    <View>
                        <Text numberOfLines={1} style={[styles.infoText,]}>{this.props.info}</Text>
                    </View>
                </TouchableOpacity>


            </View>
        )
    }
}

const styles = StyleSheet.create({

    mainContainer:
        {
            // flex: 1,
            // justifyContent:'center',
            // backgroundColor: colors.app_light_color,
            // marginTop:50
        },
    itemList:{
        minHeight:hp(11),
        width:wp(90),
        alignSelf:'center',
        borderBottomWidth:1,
        borderColor:colors.black,
        paddingHorizontal:'2%',
        marginTop:7
    },
    viewTitle:{
        flexDirection: 'row',
        alignItems:'center',
    },
    imageView:{
        width:'100%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent:'space-between',
        paddingVertical:'2%',
        paddingRight:'3%'
    },
    textView:{
        width:'100%',
        flexDirection: 'row',
        alignItems: 'center',
        justifyContent:'space-between'
    },
    icon:{
        height:25,
        width: 25,
        resizeMode:'contain',
    },
    title:{
        fontSize:wp(4.4),
        fontWeight:'bold',
        color:colors.black,
        paddingLeft:'1%'
        // paddingTop:'2%',
    },
    text:{
        fontSize:wp(3.6),
        fontWeight:'500',
        color:colors.black_shadow,
        // width:'100%',
        paddingTop:'1%',

    },
    addressText:{
        fontSize:wp(3.6),
        fontWeight:'500',
        color:colors.black_shadow,
        // width:'100%',
        paddingTop:'1%',
    },
    infoText: {
        fontSize: wp(3.6),
        fontWeight: '500',
        color: colors.black_shadow,
        paddingVertical: '2%',
        textDecorationLine:'underline'

    }


});

